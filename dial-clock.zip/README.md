# Concentric Ring Clock Dashboard

A premium, futuristic Concentric Ring Clock web application built with HTML, Vanilla CSS, and modern JavaScript. The clock features concentric rotating rings for Month, Date, and Day of the week, enclosing a central sweeping analog clock with custom greetings and a weekly activity visualization panel.

## Features

- 🕰️ **Concentric Rotating Rings**: The Month (outer), Date (middle), and Day (inner) rings rotate dynamically to align the current values at the top pointer.
- 🔄 **Shortest-Path Rotation Math**: Dials rotate forward or backward using the shortest circular distance, preventing unnatural 360-degree reverse rollbacks at midnight or month transitions.
- Sweeping Seconds Hand**: Smooth, continuous Rolex-style sweeps instead of rigid ticking, using high-performance CSS transforms and `requestAnimationFrame`.
- 📅 **Dynamic Date Calculator**: The middle date dial automatically adjusts its length (28, 29, 30, or 31 days) to match the current month, handling leap years dynamically.
- 💬 **Time-of-day Curved Greetings**: Displays a curved greeting ("GOOD MORNING", "GOOD EVENING", etc.) aligned with the current time of day inside the central dial face.
- 📊 **Weekly Activity Tracker**: A dashboard-style widget that maps out progress bars for the days of the week, highlighting the active day.
- 🎨 **Glassmorphism & Neon Glow**: Styled with modern, high-contrast obsidian backdrops, glowing indicator guidelines, and fine glass borders.
- 📱 **Fully Responsive Layout**: Scales down fluidly to fit mobile and tablet devices.

## Tech Stack

- **Markup**: Semantic HTML5
- **Styles**: Vanilla CSS3 (Custom properties, CSS Grid, Flexbox, backdrop-filter, radial gradients)
- **Logic**: Vanilla ES6 JavaScript (No JQuery, no external dependencies)
- **Fonts**: Google Fonts ("Outfit" and "JetBrains Mono")

## Getting Started

Since this is a client-side static application with no build steps, you can open and run it instantly:

### Method 1: Local File Opening
Simply clone this repository and double-click `index.html` to open it in your browser.

### Method 2: Serve Locally
If you prefer running a local server:

Using Python:
```bash
python -m http.server 8000
```
Using Node.js (`http-server`):
```bash
npx http-server
```
Then navigate to `http://localhost:8000` (or the port specified by your server).

## File Structure

```text
├── index.html      # Application structure and layout
├── clock.css       # Obsidian glassmorphism styles and animations
├── clock.js        # Mathematics, dynamic positioning, and time updates
├── LICENSE         # MIT Open-Source License
└── README.md       # Project documentation
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
